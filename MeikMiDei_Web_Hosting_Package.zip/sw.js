const CACHE="meikmidei-v6";
const ASSETS=["./","./index.html","./manifest.webmanifest","./sw.js"];

self.addEventListener("install",event=>{
  event.waitUntil(caches.open(CACHE).then(c=>c.addAll(ASSETS)).then(()=>self.skipWaiting()));
});
self.addEventListener("activate",event=>{
  event.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener("fetch",event=>{
  event.respondWith(fetch(event.request).catch(()=>caches.match(event.request)));
});
self.addEventListener("push",event=>{
  let data={title:"MeikMiDei",body:"Your class is starting now."};
  try{if(event.data)data=event.data.json()}catch{}
  event.waitUntil(self.registration.showNotification(data.title,{
    body:data.body,
    icon:"icon-192.png",
    badge:"icon-192.png",
    silent:false,
    data:{url:"./index.html"}
  }));
});
self.addEventListener("notificationclick",event=>{
  event.notification.close();
  event.waitUntil(clients.matchAll({type:"window",includeUncontrolled:true}).then(list=>{
    for(const client of list) if("focus" in client) return client.focus();
    if(clients.openWindow) return clients.openWindow("./index.html");
  }));
});
