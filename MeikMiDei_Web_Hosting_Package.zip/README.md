# MeikMiDei — Class 9C A-Week Timetable

This folder is prepared as a static website for GitHub Pages.

## Publish it

1. Create a GitHub repository, for example `meikmidei`.
2. Upload all files and folders in this folder to the repository root.
3. Make sure the default branch is `main`.
4. Open **Settings → Pages** in the repository.
5. Under **Build and deployment**, choose **GitHub Actions**.
6. Push/commit the files. The included workflow deploys the site automatically.
7. GitHub will show the published site URL in the Pages settings / workflow deployment.

The site is static HTML/CSS/JavaScript, so no server runtime is required for the basic website.

## Notifications

The site includes browser notifications, sounds, full-screen alerts while the page is open, and a service worker. The service worker also contains a Web Push handler, but true scheduled notifications while the site is completely closed require a Web Push backend that sends push messages at the timetable times. This package does not pretend that the static site alone can do that.
